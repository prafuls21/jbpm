package com.java.techhub.email.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmailDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmailDemoApplication.class, args);
	}

}
